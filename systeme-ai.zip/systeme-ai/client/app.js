const apiBase = 'http://localhost:3000'; // si tu déploies, change l'URL

document.getElementById('sendInstruction').addEventListener('click', async () => {
const instruction = document.getElementById('instruction').value;
if (!instruction) return alert('Écris une instruction');

const res = await fetch(`${apiBase}/ia/interpret`, {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ instruction })
});
const data = await res.json();
document.getElementById('aiResponse').textContent = JSON.stringify(data, null, 2);
});

// Lister contacts
document.getElementById('listContacts').addEventListener('click', async () => {
const res = await fetch(`${apiBase}/contacts`);
const data = await res.json();
document.getElementById('contactsList').textContent = JSON.stringify(data, null, 2);
});

// Exécution automatique: ATTENTION, vérifie avant d'exécuter en prod
document.getElementById('executeActions').addEventListener('click', async () => {
const txt = document.getElementById('aiResponse').textContent;
if (!txt) return alert('Aucune réponse IA à exécuter');

let ai;
try { ai = JSON.parse(txt); } catch (e) { return alert('La réponse IA doit être un JSON listant les actions'); }

if (!ai.actions) return alert('JSON attendu: { "actions": [ ... ] }');

for (const action of ai.actions) {
// action: { type, endpoint, payload }
// On mappe types simples
try {
if (action.type === 'add_contact') {
await fetch(`${apiBase}/contacts`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(action.payload) });
}
// autres types: subscribe_campaign, create_funnel, create_product etc.
} catch (err) {
console.error('Erreur action', action, err);
}
}})
