if (!name || !pages) return res.status(400).json({ error: 'name et pages nécessaires' });

// Créer funnel - endpoint hypothétique
const funnel = await systemeRequest('post', '/funnels', { name });
import express from "express";
const data = await systemeRequest('get', '/contacts');
res.json(data);
({ catch (err) {
res.status(500).json({ error: err.response?.data || err.message });
}
});

// Create funnel (simplified)
app.post('/funnels', async (req, res) => {
try {
// Exemple: { name: 'Lancement Ebook', pages: [ { type: 'sales', title, html }, ... ] }
const { name, pages } = req.body;

const createdPages = [];
for (const p of pages) {
// endpoint /pages est un exemple — adapter selon doc Systeme.io
const page = await systemeRequest('post', '/pages', {
funnel_id: funnel.id,
title: p.title,
type: p.type,
content: p.html
});
createdPages.push(page);
}

res.json({ funnel, pages: createdPages });
} catch (err) {
res.status(500).json({ error: err.response?.data || err.message });
}
});

// Create order/product (simplified)
app.post('/products', async (req, res) => {
try {
const payload = req.body; // { name, price, currency }
const product = await systemeRequest('post', '/products', payload);
res.json(product);
} catch (err) {
res.status(500).json({ error: err.response?.data || err.message });
}
});

// Get stats (simplified)
app.get('/stats', async (req, res) => {
try {
// endpoints fictifs: adapter selon la doc réelle
const sales = await systemeRequest('get', '/sales');
const contacts = await systemeRequest('get', '/contacts');

const totalOrders = sales?.totalOrders || 0;
const totalContacts = contacts?.total || contacts?.length || 0;
const conversionRate = totalContacts === 0 ? 0 : totalOrders / totalContacts;

// Suggestions basiques
const suggestions = [];
if (conversionRate < 0.02) suggestions.push('Essayez un A/B test de la page de vente ou un prix promotionnel');
if ((contacts?.open_rate || 0) < 0.2) suggestions.push('Améliorer l\'objet des emails et la segmentation');

res.json({ sales, contacts, conversionRate, suggestions });
} catch (err) {
res.status(500).json({ error: err.response?.data || err.message });
}
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
